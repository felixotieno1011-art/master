"""WebUI HTTP server — Phase 1+2+3. Port 7001. Old console (:7000) untouched."""
import http.server
import socketserver
import sys
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

PROJ = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJ))

from core.webui import aws_ref, layout, home, search, session
from core.webui.pages import s3 as s3_pages
from core.webui.pages import s3_actions, s3_wizard
from core.webui.pages import ec2 as ec2_pages
from core.webui.pages import ec2_actions


PORT_PREFERRED = 7001


def _home_html(region_code):
    return layout.page(
        "Console Home",
        home.render(region_code),
        active_service="",
        breadcrumb=[("AWS Console", "/"), ("Console Home", None)],
        region=session.region_tuple(region_code),
        path="/",
    )


def _search_html(q, region_code):
    matches, _exact = search.find(q)
    if matches:
        tiles = "".join(
            f'<a class="service-tile" href="{session.with_region(href, region_code)}">'
            f'<div class="service-tile-icon">{sid[:2].upper()}</div>'
            f'<div class="service-tile-body"><div class="service-tile-name">{name}</div>'
            f'<div class="service-tile-desc">{desc}</div></div></a>'
            for sid, name, desc, href in matches
        )
        body = f"""
<section class="aws-section">
  <h1>Search results for &ldquo;{q}&rdquo;</h1>
  <p class="aws-muted">{len(matches)} match(es)</p>
  <div class="service-grid">{tiles}</div>
</section>"""
    else:
        body = f"""
<section class="aws-section">
  <h1>No results for &ldquo;{q}&rdquo;</h1>
  <p class="aws-muted">Try S3, EC2, Lambda, IAM, CloudWatch, DynamoDB, VPC, or STS.</p>
</section>"""
    return layout.page(
        f"Search: {q}",
        body,
        breadcrumb=[("AWS Console", "/"), ("Search", None), (q or "(empty)", None)],
        region=session.region_tuple(region_code),
        path="/search",
    )


def _placeholder_service(sid, name, region_code):
    return f"""
<section class="aws-section">
  <h1>{name}</h1>
  <div class="aws-notice aws-notice-info">
    {name} workspace (tables, create-wizards, detail pages) arrives in the next phase.
  </div>
  <p class="aws-muted">
    Left-rail items mirror the real console layout. Region:
    <code>{region_code}</code> &mdash; change it with the dropdown above.
  </p>
</section>
"""


class Handler(http.server.BaseHTTPRequestHandler):

    def do_GET(self):
        split = urlsplit(self.path)
        path = split.path.rstrip("/") or "/"
        qs = parse_qs(split.query)

        try:
            region_code = session.region_from_query(qs)
            if "region" in qs and qs["region"][0] == region_code:
                if region_code != session.current_region():
                    session.set_region(region_code)

            if path == "/static/aws.css":
                return self._serve_static("aws.css", "text/css")

            if path == "/":
                return self._send_html(_home_html(region_code))

            if path == "/search":
                q = (qs.get("q") or [""])[0]
                return self._send_html(_search_html(q, region_code))

            # ---- S3 GET routes ----
            if path == "/s3":
                session.record_visit("s3")
                return self._send_html(
                    layout.page(
                        "Buckets",
                        s3_pages.render_buckets(region_code, qs=qs),
                        active_service="s3",
                        breadcrumb=[("AWS Console", "/"), ("S3", "/s3"), ("Buckets", None)],
                        region=session.region_tuple(region_code),
                        path="/s3",
                    )
                )

            if path == "/s3/create":
                session.record_visit("s3")
                return self._send_html(
                    layout.page(
                        "Create bucket",
                        s3_wizard.render_create_bucket(region_code),
                        active_service="s3",
                        breadcrumb=[("AWS Console", "/"), ("S3", "/s3"),
                                    ("Buckets", "/s3"), ("Create bucket", None)],
                        region=session.region_tuple(region_code),
                        path="/s3/create",
                    )
                )

            if path.startswith("/s3/") and path.endswith("/upload"):
                bucket_name = path[4:].split("/", 1)[0]
                session.record_visit("s3")
                return self._send_html(
                    layout.page(
                        f"Upload to {bucket_name}",
                        s3_wizard.render_upload(bucket_name),
                        active_service="s3",
                        breadcrumb=[("AWS Console", "/"), ("S3", "/s3"),
                                    ("Buckets", "/s3"), (bucket_name, None),
                                    ("Upload", None)],
                        region=session.region_tuple(region_code),
                        path=path,
                    )
                )

            if path.startswith("/s3/"):
                bucket_name = path[4:].split("/", 1)[0]
                tab = (qs.get("tab") or ["objects"])[0]
                session.record_visit("s3")
                return self._send_html(
                    layout.page(
                        bucket_name,
                        s3_pages.render_bucket(bucket_name, tab=tab,
                                               region_code=region_code, qs=qs),
                        active_service="s3",
                        breadcrumb=[("AWS Console", "/"), ("S3", "/s3"),
                                    ("Buckets", "/s3"), (bucket_name, None)],
                        region=session.region_tuple(region_code),
                        path=path,
                    )
                )

            # ---- EC2 GET routes ----
            if path == "/ec2" or path == "/ec2/instances":
                session.record_visit("ec2")
                return self._send_html(
                    layout.page(
                        "Instances",
                        ec2_pages.render_list(qs=qs),
                        active_service="ec2",
                        breadcrumb=[("AWS Console", "/"), ("EC2", "/ec2"),
                                    ("Instances", None)],
                        region=session.region_tuple(region_code),
                        path="/ec2/instances",
                    )
                )

            if path == "/ec2/launch":
                session.record_visit("ec2")
                return self._send_html(
                    layout.page(
                        "Launch an instance",
                        ec2_pages.render_launch(qs=qs),
                        active_service="ec2",
                        breadcrumb=[("AWS Console", "/"), ("EC2", "/ec2"),
                                    ("Instances", "/ec2/instances"),
                                    ("Launch an instance", None)],
                        region=session.region_tuple(region_code),
                        path="/ec2/launch",
                    )
                )

            if path.startswith("/ec2/instances/"):
                iid = path[len("/ec2/instances/"):]
                session.record_visit("ec2")
                return self._send_html(
                    layout.page(
                        iid,
                        ec2_pages.render_detail(iid, qs=qs),
                        active_service="ec2",
                        breadcrumb=[("AWS Console", "/"), ("EC2", "/ec2"),
                                    ("Instances", "/ec2/instances"),
                                    (iid, None)],
                        region=session.region_tuple(region_code),
                        path=path,
                    )
                )

            # ---- Other services: placeholder ----
            for sid, name, _desc, href in aws_ref.SERVICES:
                if path == href or path.startswith(href + "/"):
                    session.record_visit(sid)
                    return self._send_html(
                        layout.page(
                            name,
                            _placeholder_service(sid, name, region_code),
                            active_service=sid,
                            breadcrumb=[("AWS Console", "/"), (name, href), ("Overview", None)],
                            region=session.region_tuple(region_code),
                            path=path,
                        )
                    )

            return self._send_html(
                layout.page(
                    "Not Found",
                    "<h1>404 &mdash; page not found</h1>",
                    breadcrumb=[("AWS Console", "/"), ("404", None)],
                    region=session.region_tuple(region_code),
                    path=path,
                ),
                status=404,
            )
        except Exception:
            import traceback
            return self._send_html(
                f"<h1>Error</h1><pre>{traceback.format_exc()}</pre>", status=500
            )

    # ---------- POST ----------

    def do_POST(self):
        split = urlsplit(self.path)
        path = split.path.rstrip("/") or "/"

        try:
            length = int(self.headers.get("Content-Length", 0))
            ctype = (self.headers.get("Content-Type") or "").lower()

            form = {}
            files = {}

            if ctype.startswith("multipart/form-data"):
                raw = self.rfile.read(length)
                boundary = ctype.split("boundary=", 1)[1].strip().strip('"')
                form, files = _parse_multipart(raw, boundary)
            else:
                raw = self.rfile.read(length).decode("utf-8", "replace")
                parsed = parse_qs(raw, keep_blank_values=True)
                form = {k: v[0] for k, v in parsed.items()}

            result = None
            if path.startswith("/s3"):
                result = s3_actions.handle(path, form, files)
            elif path.startswith("/ec2"):
                result = ec2_actions.handle(path, form, files)

            if result is None:
                return self._send_html(
                    f"<h1>404 — no action for POST {path}</h1>", status=404
                )
            kind, payload = result
            if kind == "redirect":
                self.send_response(303)
                self.send_header("Location", payload)
                self.end_headers()
                return
            return self._send_html(payload)

            return self._send_html(f"<h1>404 — POST {path}</h1>", status=404)
        except Exception:
            import traceback
            return self._send_html(
                f"<h1>Error</h1><pre>{traceback.format_exc()}</pre>", status=500
            )

    # ---------- static / send ----------

    def _serve_static(self, filename, content_type):
        p = Path(__file__).parent / "static" / filename
        body = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html, status=200):
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        sys.stderr.write(f"  [webui] {self.address_string()} {self.requestline}\n")


def _parse_multipart(raw, boundary):
    """Minimal multipart/form-data parser (replaces the removed cgi module)."""
    result_form = {}
    result_files = {}
    sep = b"--" + boundary.encode()
    parts = raw.split(sep)
    for part in parts:
        part = part.strip(b"\r\n")
        if not part or part == b"--":
            continue
        head_end = part.find(b"\r\n\r\n")
        if head_end == -1:
            continue
        headers_blob = part[:head_end].decode("utf-8", "replace")
        body = part[head_end + 4:]
        if body.endswith(b"\r\n"):
            body = body[:-2]

        name = None
        filename = None
        ctype = "application/octet-stream"
        for line in headers_blob.split("\r\n"):
            low = line.lower()
            if low.startswith("content-disposition:"):
                for piece in line.split(";")[1:]:
                    piece = piece.strip()
                    if piece.startswith("name="):
                        name = piece.split("=", 1)[1].strip('"')
                    elif piece.startswith("filename="):
                        filename = piece.split("=", 1)[1].strip('"')
            elif low.startswith("content-type:"):
                ctype = line.split(":", 1)[1].strip()

        if name is None:
            continue
        if filename is not None:
            result_files[name] = (filename, ctype, body)
        else:
            result_form[name] = body.decode("utf-8", "replace")

    return result_form, result_files


def serve():
    for candidate in [PORT_PREFERRED, 7002, 7003]:
        try:
            httpd = socketserver.TCPServer(("", candidate), Handler)
        except OSError:
            continue
        print(f"🅰️  MiniAWS WebUI at http://localhost:{candidate}")
        print(f"   Old console (:7000) untouched.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n🛑 WebUI stopped.")
            httpd.server_close()
        return
    print("❌ No free port (tried 7001, 7002, 7003)")


if __name__ == "__main__":
    serve()
