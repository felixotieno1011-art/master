"""Convert MiniAWS data to AWS-style JSON output."""
import json
import sys
from pathlib import Path

proj = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(proj))

from core import vpc as vpc_mod
from core import ec2 as ec2_mod
from core import s3 as s3_mod
from core import iam as iam_mod
from core import cloudwatch as cw_mod
from core import account as account_mod



def describe_addresses():
    """Elastic IPs — real AWS shape."""
    from core import ec2 as ec2_mod
    eips = ec2_mod.list_addresses()
    addresses = []
    for eip in eips:
        entry = {
            "Domain": eip.get("Domain", "vpc"),
            "PublicIp": eip.get("PublicIp"),
            "AllocationId": eip.get("AllocationId"),
            "NetworkBorderGroup": eip.get("Region"),
        }
        if eip.get("InstanceId"):
            entry["InstanceId"] = eip["InstanceId"]
            entry["AssociationId"] = eip.get("AssociationId")
            entry["PrivateIpAddress"] = "10.0.0.10"
        if eip.get("Tags"):
            entry["Tags"] = [{"Key": k, "Value": v} for k, v in eip["Tags"].items()]
        addresses.append(entry)
    return {"Addresses": addresses}


def describe_vpcs():
    vpcs = vpc_mod.list_vpcs()
    acct = account_mod.get_account_id() if hasattr(account_mod, "get_account_id") else "740762029392"
    out = []
    for v in vpcs:
        vpc_id = v["vpcId"]
        cidr = v["cidrBlock"]
        tags = [{"Key": k, "Value": val} for k, val in (v.get("tags") or {}).items()]
        out.append({
            "CidrBlock": cidr,
            "DhcpOptionsId": "dopt-" + (acct or "000000000000")[:8],
            "State": v.get("state", "available"),
            "VpcId": vpc_id,
            "OwnerId": acct,
            "InstanceTenancy": "default",
            "CidrBlockAssociationSet": [
                {
                    "AssociationId": "vpc-cidr-assoc-" + vpc_id[-8:],
                    "CidrBlock": cidr,
                    "CidrBlockState": {"State": "associated"},
                }
            ],
            "IsDefault": v.get("isDefault", False),
            "Tags": tags,
        })
    return {"Vpcs": out}


def describe_subnets():
    subnets = vpc_mod.list_subnets()
    return {
        "Subnets": [
            {
                "SubnetId": s["subnetId"],
                "VpcId": s["vpcId"],
                "CidrBlock": s["cidrBlock"],
                "AvailabilityZone": s.get("availabilityZone"),
                "State": s.get("state", "available"),
                "Tags": [
                    {"Key": k, "Value": v}
                    for k, v in (s.get("tags") or {}).items()
                ],
            }
            for s in subnets
        ]
    }


def describe_internet_gateways():
    igws = vpc_mod.list_internet_gateways()
    return {
        "InternetGateways": [
            {
                "InternetGatewayId": g["internetGatewayId"],
                "Attachments": [
                    {"VpcId": vpc_id, "State": "available"}
                    for vpc_id in g.get("attachments", [])
                ],
            }
            for g in igws
        ]
    }


def describe_route_tables():
    rts = vpc_mod.list_route_tables()
    return {
        "RouteTables": [
            {
                "RouteTableId": rt["routeTableId"],
                "VpcId": rt["vpcId"],
                "Routes": [
                    {
                        "DestinationCidrBlock": r["destinationCidrBlock"],
                        "GatewayId": r["gatewayId"],
                        "State": r.get("state", "active"),
                    }
                    for r in rt.get("routes", [])
                ],
            }
            for rt in rts
        ]
    }


def describe_instances():
    instances = ec2_mod.list_all()
    return {
        "Reservations": [
            {
                "Instances": [
                    {
                        "InstanceId": i["instance_id"],
                        "InstanceType": i["instance_type"],
                        "State": {"Name": i.get("state")},
                        "Region": i.get("region"),
                        "Tags": [
                            {"Key": k, "Value": v}
                            for k, v in (i.get("tags") or {}).items()
                        ],
                    }
                    for i in instances
                ]
            }
        ]
    }



def describe_availability_zones():
    from core import az, account
    region = account.get_region()
    return {"AvailabilityZones": az.get_az_details(region)}

def list_buckets():
    buckets = s3_mod.ls_buckets()
    return {
        "Buckets": [
            {
                "Name": b["name"],
                "CreationDate": b.get("created"),
                "Region": b.get("region"),
            }
            for b in buckets
        ]
    }


def list_users():
    users = iam_mod.list_users()
    return {
        "Users": [
            {
                "UserName": u["userName"],
                "Arn": u["arn"],
                "CreateDate": u.get("created"),
            }
            for u in users
        ]
    }


def list_access_keys():
    """Handler for 'iam list-access-keys --user-name <u>'."""
    # The command requires --user-name. We support the common case where
    # the user was passed as a flag. If not provided, return all users' keys.
    import sys as _s
    args = _s.argv
    uname = None
    for i, a in enumerate(args):
        if a == "--user-name" and i + 1 < len(args):
            uname = args[i + 1]
            break
    if not uname:
        # No user specified — return an empty AccessKeyMetadata list
        return {"AccessKeyMetadata": []}
    keys, err = iam_mod.list_access_keys(uname)
    if keys is None:
        return {"AccessKeyMetadata": []}
    return {
        "AccessKeyMetadata": [
            {
                "UserName": uname,
                "AccessKeyId": k["accessKeyId"],
                "Status": k.get("status", "Active"),
                "CreateDate": k.get("created"),
            }
            for k in keys
        ]
    }


def describe_user():
    """Handler for 'iam get-user --user-name <u>'."""
    import sys as _s
    args = _s.argv
    uname = None
    for i, a in enumerate(args):
        if a == "--user-name" and i + 1 < len(args):
            uname = args[i + 1]
            break
        if a in ("-u",) and i + 1 < len(args):
            uname = args[i + 1]
            break
    if not uname:
        return {"User": None}
    u = iam_mod.get_user(uname)
    if not u:
        return {"User": None}
    return {
        "User": {
            "UserName": u.get("userName"),
            "Arn": u.get("arn"),
            "CreateDate": u.get("created"),
            "Path": u.get("path", "/"),
        }
    }


def list_groups():
    groups = iam_mod.list_groups()
    return {
        "Groups": [
            {
                "GroupName": g.get("groupName"),
                "Arn": g.get("arn"),
                "CreateDate": g.get("created"),
            }
            for g in groups
        ]
    }


def list_alarms():
    alarms = cw_mod.list_alarms()
    return {
        "MetricAlarms": [
            {
                "AlarmName": a["alarmName"],
                "MetricName": a["metricName"],
                "Namespace": a["namespace"],
                "StateValue": a["stateValue"],
                "StateReason": a.get("stateReason", ""),
                "Threshold": a["threshold"],
                "ComparisonOperator": a["comparisonOperator"],
            }
            for a in alarms
        ]
    }


# Dispatch table
HANDLERS = {
    "describe-vpcs": describe_vpcs,
    "describe-availability-zones": describe_availability_zones,
    "describe-addresses": describe_addresses,
    "describe-subnets": describe_subnets,
    "describe-internet-gateways": describe_internet_gateways,
    "describe-route-tables": describe_route_tables,
    "describe-instances": describe_instances,
    "list-buckets": list_buckets,
    "list-users": list_users,
    "list-access-keys": list_access_keys,
    "get-user": describe_user,
    "list-groups": list_groups,
    "list-alarms": list_alarms,
}


def main():
    if len(sys.argv) < 2:
        print("usage: json_output.py <command>")
        sys.exit(1)
    cmd = sys.argv[1]
    handler = HANDLERS.get(cmd)
    if not handler:
        print(f"❌ no JSON handler for: {cmd}", file=sys.stderr)
        sys.exit(1)
    result = handler()
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
