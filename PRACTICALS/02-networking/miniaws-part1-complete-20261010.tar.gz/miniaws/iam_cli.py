#!/usr/bin/env python3
"""IAM commands — standalone or via `python iam_cli.py <subcmd>`."""
import json
import sys
import utils
from core import iam, iam_seed
from lib.errors import AWSError, wrap_legacy


def parse(args):
    """Return (flags_dict, positional_list).

    Real AWS CLI flag names are captured under both their real name AND
    the legacy shorter alias so old callers keep working.

    e.g. --user-name alice  ->  flags["user-name"] = "alice", flags["user"] = "alice"
         --policy-arn X     ->  flags["policy-arn"] = X,        flags["policy"] = X
         --group-name Y     ->  flags["group-name"] = Y,        flags["group"] = Y
    """
    flags = {}
    positional = []
    i = 0
    while i < len(args):
        a = args[i]
        if a.startswith("--"):
            if "=" in a:
                k, v = a[2:].split("=", 1)
                flags[k] = v
                i += 1
            else:
                k = a[2:]
                if i + 1 < len(args) and not args[i + 1].startswith("--"):
                    flags[k] = args[i + 1]
                    i += 2
                else:
                    flags[k] = True
                    i += 1
            # Alias real AWS names to legacy short names
            alias = {"user-name": "user", "group-name": "group",
                     "policy-arn": "policy", "policy-name": "policy"}
            if k in alias:
                flags.setdefault(alias[k], flags[k])
        else:
            positional.append(a)
            i += 1
    return flags, positional


_DRY_RUN_IAM = {
    "create-user":         ("CreateUser",         "create-user"),
    "delete-user":         ("DeleteUser",         "delete-user"),
    "create-group":        ("CreateGroup",        "create-group"),
    "delete-group":        ("DeleteGroup",        "delete-group"),
    "attach-user-policy":  ("AttachUserPolicy",   "attach-user-policy"),
    "detach-user-policy":  ("DetachUserPolicy",   "detach-user-policy"),
    "attach-group-policy": ("AttachGroupPolicy",  "attach-group-policy"),
    "detach-group-policy": ("DetachGroupPolicy",  "detach-group-policy"),
    "create-policy":       ("CreatePolicy",       "create-policy"),
    "delete-policy":       ("DeletePolicy",       "delete-policy"),
    "create-access-key":   ("CreateAccessKey",    "create-access-key"),
    "delete-access-key":   ("DeleteAccessKey",    "delete-access-key"),
}


def _check_dry_run(sub, flags):
    """Raise DryRunOperation (exit 255, no side effects) if --dry-run is set
    on a write command."""
    if sub not in _DRY_RUN_IAM:
        return
    v = flags.get("dry-run")
    if v is True or v == "true":
        op, display = _DRY_RUN_IAM[sub]
        err = AWSError(
            code="DryRunOperation",
            message="Request would have succeeded, but DryRun flag is set.",
            operation=op,
            exit_code=255,
        )
        err._operation_display = display
        raise err


def _resolve_user(flags, rest):
    """Get username from --user-name / --user flag, falling back to positional[0]."""
    for k in ("user-name", "user"):
        v = flags.get(k)
        if isinstance(v, str) and v:
            return v
    if rest and isinstance(rest[0], str) and not rest[0].startswith("--"):
        return rest[0]
    return None


def _resolve_group(flags, rest):
    for k in ("group-name", "group"):
        v = flags.get(k)
        if isinstance(v, str) and v:
            return v
    if rest and isinstance(rest[0], str) and not rest[0].startswith("--"):
        return rest[0]
    return None


def _resolve_policy(flags, rest):
    for k in ("policy-arn", "policy-name", "policy"):
        v = flags.get(k)
        if isinstance(v, str) and v:
            return v
    if rest and isinstance(rest[0], str) and not rest[0].startswith("--"):
        return rest[0]
    return None


USAGE = """
IAM COMMANDS:
  login <user>                             (or 'root' for full access)
  logout
  whoami

  seed                                     (create common policies)

  create-user <username>
  list-users
  delete-user <username>

  create-group <name>
  list-groups
  delete-group <name>
  add-user-to-group <user> <group>
  remove-user-from-group <user> <group>

  create-policy <name> --file <path.json>
  list-policies
  show-policy <name>
  delete-policy <name>

  create-access-key --user-name <u>
  list-access-keys --user-name <u>
  delete-access-key --user-name <u> --access-key-id <id>

  attach-user-policy --user-name <u> --policy-arn <arn>
  detach-user-policy --user <u> --policy <p>
  attach-group-policy --group <g> --policy <p>
  detach-group-policy --group <g> --policy <p>

  can <action> [--resource <r>]            (test permissions)

  audit [--limit N]
"""


VALID_IAM_FLAGS = {
    "login":                  {"user-name"},
    "logout":                 set(),
    "whoami":                 set(),
    "seed":                   set(),
    "create-user":            {"user-name", "tags"},
    "list-users":             set(),
    "delete-user":            {"user-name"},
    "create-group":           {"group-name"},
    "list-groups":            set(),
    "delete-group":           {"group-name"},
    "add-user-to-group":      {"user-name", "group-name"},
    "remove-user-from-group": {"user-name", "group-name"},
    "create-policy":          {"policy-name", "policy-document", "file"},
    "list-policies":          set(),
    "show-policy":            {"policy-name"},
    "delete-policy":          {"policy-name"},
    "get-user":               {"user-name"},
"create-access-key":      {"user-name"},
    "list-access-keys":       {"user-name"},
    "delete-access-key":      {"user-name", "access-key-id"},
    "attach-user-policy":     {"user-name", "user", "policy-arn", "policy"},
    "detach-user-policy":     {"user-name", "user", "policy-arn", "policy"},
    "attach-group-policy":    {"group-name", "group", "policy-arn", "policy"},
    "detach-group-policy":    {"group-name", "group", "policy-arn", "policy"},
    "can":                    {"resource"},
    "audit":                  {"limit"},
}

# Alias keys produced by parse() that should never trigger UnknownOptions.
# Every real flag like --user-name also appears in flags as "user", etc.
_ALIAS_KEYS = {"user", "group", "policy"}

COMMON_IAM_FLAGS = {
    "dry-run", "output", "query", "region", "profile", "endpoint-url",
    "debug", "no-verify-ssl", "no-paginate", "no-sign-request",
} | _ALIAS_KEYS


def _strict_iam_flags(sub, flags):
    """Raise UnknownOptions (exit 255) if any flag isn't whitelisted for sub."""
    allowed = VALID_IAM_FLAGS.get(sub, set()) | COMMON_IAM_FLAGS
    for k in flags:
        if k not in allowed:
            raise AWSError(
                code="UnknownOptions",
                message=f"Unknown options: --{k}",
                operation=f"iam:{sub}",
                exit_code=255,
            )


def cmd(args):
    if not args or args[0] in ("-h", "--help", "help"):
        print(USAGE); return 1
    sub, raw_rest = args[0], args[1:]
    flags, rest = parse(raw_rest)
    _check_dry_run(sub, flags)
    _strict_iam_flags(sub, flags)

    # --- login / logout / whoami ---
    if sub == "login":
        if not rest:
            print(utils.err("username required")); return 1
        ok_, msg = iam.login(rest[0])
        print(utils.ok(msg) if ok_ else utils.err(msg))
        return 0 if ok_ else 1
    if sub == "logout":
        iam.logout()
        print(utils.ok("logged out")); return 0
    if sub == "whoami":
        u = iam.get_current_user()
        if not u:
            print(utils.warn("not logged in")); return 0
        print(f"👤 {u}")
        return 0

    # --- seed ---
    if sub == "seed":
        n = iam_seed.seed()
        print(utils.ok(f"seeded {n} policies"))
        return 0

    # --- users ---
    if sub == "create-user":
        uname = _resolve_user(flags, rest)
        if not uname:
            print(utils.err("username required")); return 1
        if not _need("iam:CreateUser"): return 1
        ok_, msg = iam.create_user(uname)
        if not ok_:
            if "already exists" in msg:
                raise wrap_legacy(False, msg, operation="CreateUser",
                                  resource=f"arn:aws:iam::*:user/{uname}",
                                  code="EntityAlreadyExists")
            raise wrap_legacy(False, msg, operation="CreateUser",
                              resource=f"arn:aws:iam::*:user/{uname}",
                              code="InvalidParameterValue")
        print(utils.ok(msg))
        iam.audit("iam:CreateUser", uname)
        return 0
    if sub == "list-users":
        if not _need("iam:ListUsers"): return 1
        users = iam.list_users()
        if not users:
            print(utils.warn("no users")); return 0
        print(f"{'USERNAME':<20} {'ARN':<60}")
        print("-" * 80)
        for u in users:
            uname = u.get("userName") or u.get("username") or "(unknown)"
            arn = u.get("arn") or "(missing arn)"
            print(f"{uname:<20} {arn:<60}")
        return 0
    if sub == "delete-user":
        uname = _resolve_user(flags, rest)
        if not uname:
            print(utils.err("username required")); return 1
        if not _need("iam:DeleteUser"): return 1
        ok_, msg = iam.delete_user(uname)
        if not ok_:
            m = msg.lower()
            if "still" in m or "attached" in m or "access key" in m or "must delete" in m:
                code = "DeleteConflict"
            else:
                code = "NoSuchEntity"
            raise wrap_legacy(False, msg, operation="DeleteUser",
                              resource=f"arn:aws:iam::*:user/{uname}",
                              code=code)
        print(utils.ok(msg))
        iam.audit("iam:DeleteUser", uname)
        return 0

    # --- groups ---
    if sub == "create-group":
        if not rest:
            print(utils.err("group name required")); return 1
        if not _need("iam:CreateGroup"): return 1
        ok_, msg = iam.create_group(rest[0])
        print(utils.ok(msg) if ok_ else utils.err(msg))
        if ok_: iam.audit("iam:CreateGroup", rest[0])
        return 0 if ok_ else 1
    if sub == "list-groups":
        if not _need("iam:ListGroups"): return 1
        groups = iam.list_groups()
        if not groups:
            print(utils.warn("no groups")); return 0
        for g in groups:
            print(f"  {g['groupName']:<20} members: {len(g.get('members',[]))}  policies: {len(g.get('attachedPolicies',[]))}")
        return 0
    if sub == "delete-group":
        if not rest:
            print(utils.err("group name required")); return 1
        if not _need("iam:DeleteGroup"): return 1
        ok_, msg = iam.delete_group(rest[0])
        print(utils.ok(msg) if ok_ else utils.err(msg))
        return 0 if ok_ else 1
    if sub == "add-user-to-group":
        if len(rest) < 2:
            print(utils.err("usage: add-user-to-group <user> <group>")); return 1
        if not _need("iam:AddUserToGroup"): return 1
        ok_, msg = iam.add_user_to_group(rest[0], rest[1])
        print(utils.ok(msg) if ok_ else utils.err(msg))
        return 0 if ok_ else 1
    if sub == "remove-user-from-group":
        if len(rest) < 2:
            print(utils.err("usage: remove-user-from-group <user> <group>")); return 1
        if not _need("iam:RemoveUserFromGroup"): return 1
        ok_, msg = iam.remove_user_from_group(rest[0], rest[1])
        print(utils.ok(msg) if ok_ else utils.err(msg))
        return 0 if ok_ else 1

    # --- policies ---
    if sub == "create-policy":
        if not rest:
            print(utils.err("policy name required")); return 1
        if not _need("iam:CreatePolicy"): return 1
        fpath = flags.get("file")
        if not fpath:
            print(utils.err("--file <path.json> required")); return 1
        try:
            with open(fpath) as f:
                doc = json.load(f)
        except Exception as e:
            print(utils.err(f"failed to read {fpath}: {e}")); return 1
        ok_, msg = iam.create_policy(rest[0], doc)
        print(utils.ok(msg) if ok_ else utils.err(msg))
        if ok_: iam.audit("iam:CreatePolicy", rest[0])
        return 0 if ok_ else 1
    if sub == "list-policies":
        if not _need("iam:ListPolicies"): return 1
        policies = iam.list_policies()
        if not policies:
            print(utils.warn("no policies. Run: python iam_cli.py seed")); return 0
        for p in policies:
            print(f"  {p['policyName']:<25} {p['arn']}")
        return 0
    if sub == "show-policy":
        if not rest:
            print(utils.err("policy name required")); return 1
        p = iam.get_policy(rest[0])
        if not p:
            print(utils.err(f"policy '{rest[0]}' not found")); return 1
        print(json.dumps(p, indent=2))
        return 0
    if sub == "delete-policy":
        if not rest:
            print(utils.err("policy name required")); return 1
        if not _need("iam:DeletePolicy"): return 1
        ok_, msg = iam.delete_policy(rest[0])
        print(utils.ok(msg) if ok_ else utils.err(msg))
        return 0 if ok_ else 1

    # --- get-user ---
    if sub == "get-user":
        uname = _resolve_user(flags, rest)
        if not uname:
            uname = iam.get_current_user()
        if not uname:
            print(utils.err("--user-name required")); return 1
        u = iam.get_user(uname)
        if not u:
            raise wrap_legacy(False, f"user '{uname}' not found",
                              operation="GetUser",
                              resource=f"arn:aws:iam::*:user/{uname}",
                              code="NoSuchEntity")
        import json as _json
        # Match AWS GetUser shape
        out = {
            "User": {
                "Path": u.get("path", "/"),
                "UserName": u.get("userName"),
                "UserId": u.get("userId", ""),
                "Arn": u.get("arn"),
                "CreateDate": u.get("created"),
            }
        }
        print(_json.dumps(out, indent=2))
        return 0

    # --- access keys ---
    if sub == "create-access-key":
        uname = _resolve_user(flags, rest)
        if not uname:
            print(utils.err("--user-name required")); return 1
        ok_, res = iam.create_access_key(uname)
        if not ok_:
            raise wrap_legacy(False, res, operation="CreateAccessKey",
                              resource=f"arn:aws:iam::*:user/{uname}",
                              code="NoSuchEntity")
        # Print both AccessKeyId and SecretAccessKey (like real AWS)
        akid = res
        keys, _ = iam.list_access_keys(uname)
        secret = next((k["secretAccessKey"] for k in keys if k["accessKeyId"] == akid), "")
        print(f"Access Key ID:     {akid}")
        print(f"Secret Access Key: {secret}")
        return 0

    if sub == "list-access-keys":
        uname = _resolve_user(flags, rest)
        if not uname:
            print(utils.err("--user-name required")); return 1
        keys, err = iam.list_access_keys(uname)
        if keys is None:
            raise wrap_legacy(False, err, operation="ListAccessKeys",
                              resource=f"arn:aws:iam::*:user/{uname}",
                              code="NoSuchEntity")
        if not keys:
            print(utils.warn("no access keys")); return 0
        print(f"{'ACCESS KEY ID':<24} {'STATUS':<10} {'CREATED':<22}")
        print("-" * 60)
        for k in keys:
            print(f"{k['accessKeyId']:<24} {k.get('status','Active'):<10} {k.get('created',''):<22}")
        return 0

    if sub == "delete-access-key":
        uname = _resolve_user(flags, rest)
        akid = flags.get("access-key-id")
        if not uname or not akid:
            print(utils.err("--user-name and --access-key-id required")); return 1
        ok_, msg = iam.delete_access_key(uname, akid)
        if not ok_:
            raise wrap_legacy(False, msg, operation="DeleteAccessKey",
                              resource=f"arn:aws:iam::*:user/{uname}",
                              code="NoSuchEntity")
        print(utils.ok(msg))
        return 0

    # --- attach ---
    if sub in ("attach-user-policy", "detach-user-policy"):
        u = _resolve_user(flags, [])
        p = _resolve_policy(flags, [])
        if not u or not p:
            print(utils.err("--user-name <u> --policy-arn <p> required")); return 1
        if not _need("iam:AttachUserPolicy"): return 1
        fn = iam.attach_user_policy if sub == "attach-user-policy" else iam.detach_user_policy
        opname = "AttachUserPolicy" if sub == "attach-user-policy" else "DetachUserPolicy"
        ok_, msg = fn(u, p)
        if not ok_:
            if "not found" in msg:
                code = "NoSuchEntity"
            elif "not attached" in msg:
                code = "NoSuchEntity"
            elif "already attached" in msg:
                code = "EntityAlreadyExists"
            else:
                code = "ClientError"
            raise wrap_legacy(False, msg, operation=opname,
                              resource=f"arn:aws:iam::*:user/{u}",
                              code=code)
        print(utils.ok(msg))
        return 0
    if sub in ("attach-group-policy", "detach-group-policy"):
        g = _resolve_group(flags, [])
        p = _resolve_policy(flags, [])
        if not g or not p:
            print(utils.err("--group-name <g> --policy-arn <p> required")); return 1
        if not _need("iam:AttachGroupPolicy"): return 1
        fn = iam.attach_group_policy if sub == "attach-group-policy" else iam.detach_group_policy
        ok_, msg = fn(g, p)
        print(utils.ok(msg) if ok_ else utils.err(msg))
        return 0 if ok_ else 1

    # --- can ---
    if sub == "can":
        if not rest:
            print(utils.err("usage: can <action> [--resource <r>]")); return 1
        action = rest[0]
        resource = flags.get("resource") or "*"
        allowed, reason = iam.can(action, resource)
        if allowed:
            print(utils.ok(f"ALLOWED: {action}"))
        else:
            print(utils.err(f"DENIED:  {action}  ({reason})"))
        return 0 if allowed else 1

    # --- audit ---
    if sub == "audit":
        limit = int(flags.get("limit", 30)) if isinstance(flags.get("limit"), str) else 30
        lines = iam.read_audit(limit)
        if not lines:
            print(utils.warn("no audit entries")); return 0
        print(f"Last {len(lines)} audit entries:")
        print("-" * 80)
        for l in lines:
            print(l)
        return 0

    print(utils.err(f"unknown iam subcommand: {sub}")); return 1


def _need(action):
    allowed, reason = iam.can(action)
    if not allowed:
        print(utils.err(reason))
        iam.audit(action, "", success=False)
        return False
    return True


_JSON_HANDLERS_IAM = {
    ("list-users",):        "list-users",
    ("list-access-keys",):  "list-access-keys",
    ("get-user",):          "get-user",
    ("list-groups",):       "list-groups",
}


def _try_iam_json(args):
    """If args contain --output json or --query AND a JSON handler exists,
    print AWS-shaped JSON and return True. Otherwise return False."""
    import importlib
    output_format = None
    query_expr = None
    positional = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--output" and i + 1 < len(args):
            output_format = args[i + 1]; i += 2; continue
        if a.startswith("--output="):
            output_format = a.split("=", 1)[1]; i += 1; continue
        if a == "--query" and i + 1 < len(args):
            query_expr = args[i + 1]; i += 2; continue
        if a.startswith("--query="):
            query_expr = a.split("=", 1)[1]; i += 1; continue
        if a.startswith("--"):
            if i + 1 < len(args) and not args[i + 1].startswith("--"):
                i += 2
            else:
                i += 1
            continue
        positional.append(a)
        i += 1

    if not (output_format == "json" or query_expr is not None):
        return False
    if not positional:
        return False

    key = _JSON_HANDLERS_IAM.get((positional[0],))
    if not key:
        return False

    jo = importlib.import_module("lib.json_output")
    handler = jo.HANDLERS.get(key)
    if not handler:
        return False

    result = handler()

    if query_expr:
        import jmespath
        from lib.errors import AWSError as _AWSError
        try:
            result = jmespath.search(query_expr, result)
        except Exception as e:
            raise _AWSError(
                code="InvalidParameterValue",
                message=f"Bad --query expression: {e}",
                operation="Query",
                exit_code=255,
            )

    import json as _json
    print(_json.dumps(result, indent=2))
    return True


def _safe_main():
    """Entry point that routes AWSError through the AWS template + stderr."""
    from lib.errors import AWSError as _AWSError, format_aws_error as _fmt_err
    try:
        if _try_iam_json(sys.argv[1:]):
            return 0
    except _AWSError as e:
        sys.stderr.write(_fmt_err(e) + "\n")
        return e.exit_code
    except Exception as e:
        sys.stderr.write(f"❌ JSON output failed: {type(e).__name__}: {e}\n")
        return 1

    try:
        rc = cmd(sys.argv[1:])
        return rc if isinstance(rc, int) else 0
    except _AWSError as e:
        sys.stderr.write(_fmt_err(e) + "\n")
        return e.exit_code
    except KeyboardInterrupt:
        sys.stderr.write("\nInterrupted.\n")
        return 130


if __name__ == "__main__":
    sys.exit(_safe_main())
