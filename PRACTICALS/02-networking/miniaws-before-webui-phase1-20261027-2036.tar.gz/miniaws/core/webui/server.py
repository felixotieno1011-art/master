"""Phase 0 server — proves the AWS shell renders. Port 7001, never 7000.

Read-only. No create actions yet — those come in Phase 3.
"""
import http.server
import socketserver
import sys
from pathlib import Path
from urllib.parse import urlsplit

# Make project root importable when launched via `python3 webui.py`
PROJ = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJ))

from core.webui import aws_ref, layout


PORT_PREFERRED = 7001


def _home_content():
    tiles = []
    for sid, name, desc, href in aws_ref.SERVICES:
        tiles.append(f"""
        <a class="service-tile" href="{href}">
          <div class="service-tile-icon">{sid[:2].upper()}</div>
          <div class="service-tile-body">
            <div class="service-tile-name">{name}</div>
            <div class="service-tile-desc">{desc}</div>
          </div>
        </a>""")
    return f"""
<section class="aws-section">
  <h1>Welcome to MiniAWS</h1>
  <p class="aws-muted">A local, offline teaching simulator of the AWS Console.
     Pick a service to explore — same names, same layout, no bill.</p>
</section>
<section class="aws-section">
  <h2>Recently visited</h2>
  <div class="service-grid">{"".join(tiles)}</div>
</section>
"""


def _placeholder_service(sid, name):
    return f"""
<section class="aws-section">
  <h1>{name}</h1>
  <div class="aws-notice aws-notice-info">
    Phase 0 — the {name} workspace will be built in Phase 2–3.
    The shell, header, sidebar and breadcrumb are live; the tables and
    create-wizards come next.
  </div>
  <p class="aws-muted">Left-rail items are placeholders and match the real console layout.</p>
</section>
"""


class Handler(http.server.BaseHTTPRequestHandler):

    def do_GET(self):
        path = urlsplit(self.path).path.rstrip("/") or "/"
        try:
            if path == "/static/aws.css":
                return self._serve_css()
            if path == "/":
                html = layout.page(
                    "Console Home",
                    _home_content(),
                    active_service="",
                    breadcrumb=[("AWS Console", "/"), ("Console Home", None)],
                    path="/",
                )
                return self._send_html(html)

            # Per-service placeholder (so sidebar/breadcrumb are exercised)
            for sid, name, _desc, href in aws_ref.SERVICES:
                if path == href or path.startswith(href + "/"):
                    html = layout.page(
                        name,
                        _placeholder_service(sid, name),
                        active_service=sid,
                        breadcrumb=[("AWS Console", "/"), (name, href), ("Overview", None)],
                        path=path,
                    )
                    return self._send_html(html)

            return self._send_html(
                layout.page("Not Found",
                            "<h1>404 — page not found</h1>",
                            breadcrumb=[("AWS Console", "/"), ("404", None)],
                            path=path),
                status=404,
            )
        except Exception:
            import traceback
            return self._send_html(
                f"<h1>Error</h1><pre>{traceback.format_exc()}</pre>", status=500
            )

    def _serve_css(self):
        css_path = Path(__file__).parent / "static" / "aws.css"
        body = css_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/css; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html, status=200):
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        sys.stderr.write(f"  [webui] {self.address_string()} {self.requestline}\n")


def serve():
    for candidate in [PORT_PREFERRED, 7002, 7003]:
        try:
            httpd = socketserver.TCPServer(("", candidate), Handler)
        except OSError:
            continue
        print(f"🅰️  MiniAWS WebUI at http://localhost:{candidate}")
        print(f"   AWS-faithful shell — old console (:7000) untouched.")
        print(f"   Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n🛑 WebUI stopped.")
            httpd.server_close()
        return
    print("❌ No free port (tried 7001, 7002, 7003)")


if __name__ == "__main__":
    serve()
