# Session Log — MiniAWS

## Session: 2026-10-05 — Chapter 5 Complete ✅
**Goal:** Give the private subnet outbound-only internet access. ✅ Achieved.

### Current Infrastructure
- VPC:            vpc-d49769ed81d046a79  (10.0.0.0/16)
- Public subnet:  subnet-497b38a8f4f544dd9  (10.0.1.0/24, public-1)
- Private subnet: subnet-3277d9a129b2472c8  (10.0.2.0/24, private-1)
- IGW:            igw-2c9fb7e69a094c6aa  (attached)
- NAT Gateway:    nat-0c2a82ceb0074d598  (in public-1, public IP 203.0.113.10)
- Main RT:        rtb-ca302df68d6b427e9  (local + 0.0.0.0/0 → IGW)
- Private RT:     rtb-3fcb0396fad94fb3b  (local + 0.0.0.0/0 → NAT)
                  associated with subnet-3277d9a129b2472c8

### Chapter 5 — Progress
- [x] Create VPC
- [x] Create public + private subnets
- [x] Create + attach Internet Gateway
- [x] Add internet route to main RT
- [x] Create NAT Gateway in public subnet
- [x] Create private route table
- [x] Add NAT route to private RT
- [x] Associate private RT with private subnet
- [x] Verify routes

### Vocabulary
- VPC = private network in AWS
- Subnet = slice of the VPC (public faces internet, private hidden)
- IGW = door to the internet (two-way traffic)
- NAT Gateway = mail slot (outbound only, has its own public IP)
- Route table = signpost telling packets where to go
- Main route table = auto-created with VPC, used by default
- Private route table = custom, associated with private subnets

### Next Chapter (6)
- Route tables deeper: peering, VPN, transit gateway
- Multi-tier architectures
- Security Groups (firewalls for instances)

---

## Session: 2026-10-06 — Help System Added
**Goal:** Add `--help` support to all commands. ✅ Achieved.

### What we built
- `core/help_text.py` — help text for ~30 commands
- Wrapper: detects `--help`, looks up, prints, exits
- Every command now self-documents

### Example

### Why this matters
- Future-you can look up syntax without leaving Termux
- Matches real AWS behavior (per-command help)
- Makes MiniAWS feel like a real CLI tool
